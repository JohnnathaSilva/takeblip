package takeBlip;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//classe
public class Cadastro {
	// WebDriver webDriver;

	// atributos
	private WebDriver driver;

	// m�todos

	@SuppressWarnings("deprecation")
	@Before
	public void setUp() {

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("incognito");
		options.addArguments("start-maximized");
		options.addArguments("disable-infobars");
		options.addArguments("--disable-extensions");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver/chromedriver.exe");
		driver = new ChromeDriver(capabilities);

	}

	@After
	public void tearDown() {
		// driver.quit();
	}

	@Test
	public void blip() {
		// driver.manage().window().maximize();
		driver.get("https://account.blip.ai/");
		driver.findElement(By.id("blip-register")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.id("FullName")).click();
		driver.findElement(By.id("FullName")).sendKeys("Johnnatha Gon�alves da Silva");
		driver.findElement(By.id("Email")).sendKeys("johnnathagoncalvesdasilva@hotmail.com");
		driver.findElement(By.id("Password")).sendKeys("Teste2022!");
		driver.findElement(By.id("PhoneNumber")).click();
		driver.findElement(By.id("PhoneNumber")).sendKeys("+55 81 99672 4998");

		driver.findElement(By.id("CompanySite")).click();
		driver.findElement(By.id("CompanySite")).sendKeys("blip.com");
		{
			WebElement element = driver.findElement(By.id("register-form"));
			Actions builder = new Actions(driver);
			builder.moveToElement(element).perform();
		}

		driver.findElement(By.tagName("BDS-CHECKBOX")).click();
		driver.findElement(By.className("g-recaptcha")).click();
		new WebDriverWait(driver, 10).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By
				.xpath("//iframe[starts-with(@name, 'a-') and starts-with(@src, 'https://www.google.com/recaptcha')]")));
		new WebDriverWait(driver, 20)
				.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div.recaptcha-checkbox-checkmark")))
				.click();
		driver.findElement(By.id("submitButton")).click();

	}
}
