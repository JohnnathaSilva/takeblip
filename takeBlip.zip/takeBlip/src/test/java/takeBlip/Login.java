package takeBlip;

import java.util.Arrays;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

//classe
public class Login {
	// WebDriver webDriver;

	// atributos
	private WebDriver driver;

	// m�todos

	@SuppressWarnings("deprecation")
	@Before
	public void setUp() {

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		ChromeOptions option = new ChromeOptions();
		option.addArguments("incognito");
		capabilities.setCapability(ChromeOptions.CAPABILITY, option);
		capabilities.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver/chromedriver.exe");
		driver = new ChromeDriver(capabilities);

		// webDriver.manage().window().maximize();
	}

	@After
	public void tearDown() {
		// driver.quit();
	}

	@Test
	public void blip() {
		driver.manage().window().maximize();
		driver.get("https://account.blip.ai/");
		
		driver.findElement(By.id("email")).click();
	    driver.findElement(By.id("email")).sendKeys("johnnathati@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("Teste2022!");
	    {
	      WebElement element = driver.findElement(By.id("blip-login"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    driver.findElement(By.id("blip-login")).click();

		
		  
		 
	}
}
